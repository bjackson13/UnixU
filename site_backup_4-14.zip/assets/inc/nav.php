<div id='nav'>

    <div class="menu-option">
        <button class="menu-button">About</button>
            <div  class="list-items">
                <a <?php echo($page == 'UnixU')?'class="active"':'';?> href="<?php echo $path;?>about/unixu.php">UnixU</a>
                <a <?php echo($page == 'people')?'class="active"':'';?> href="<?php echo $path;?>about/people.php">Our People</a>
            </div>
    </div>

    <div class="menu-option">
        <button class="menu-button">References</button>
            <div  class="list-items">
                <a <?php echo($page == 'general')?'class="active"':'';?> href="<?php echo $path;?>references/general.php">General</a>
                <a <?php echo($page == 'commands')?'class="active"':'';?> href="<?php echo $path;?>references/commands.php">Commands</a>
                <a <?php echo($page == 'permissions')?'class="active"':'';?> href="<?php echo $path;?>references/permissions.php">Permissions</a>
                <a <?php echo($page == 'files')?'class="active"':'';?> href="<?php echo $path;?>references/files.php">File structure</a>
                <a <?php echo($page == 'bash')?'class="active"':'';?> href="<?php echo $path;?>references/bash.php">Bash</a>
            </div>
    </div>

    <div class="menu-option">
        <button class="menu-button">Quizzes</button>
            <div  class="list-items">
              <a <?php echo($page == 'general-quiz')?'class="active"':'';?> href="<?php echo $path;?>quizzes/general-quiz.php">General</a>
              <a <?php echo($page == 'commands-quiz')?'class="active"':'';?> href="<?php echo $path;?>quizzes/commands-quiz.php">Commands</a>
              <a <?php echo($page == 'permissions-quiz')?'class="active"':'';?> href="<?php echo $path;?>quizzes/permissions-quiz.php">Permissions</a>
              <a <?php echo($page == 'files-quiz')?'class="active"':'';?> href="<?php echo $path;?>quizzes/files-quiz.php">File structure</a>
              <a <?php echo($page == 'bash-quiz')?'class="active"':'';?> href="<?php echo $path;?>quizzes/bash-quiz.php">Bash</a>
            </div>
    </div>

    <div class="menu-option">
        <button class="menu-button">Login</button>
    </div>

</div>
