<?php $conn = new mysqli('localhost', 'iste240t11', 'longsort', 'iste240t11');

//error checking
if(mysqli_connect_errno()){
    printf("connection failed: ", mysqli_connect_errno());
    exit();
}
?>
