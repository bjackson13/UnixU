<?php
  /*You only need to change this stuff!*/
    $page = 'general-quiz';
    $quiz = 'general';
    $path = '../';

    require $path.'dbConn.php';

?>

<?php?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
      <title>General Quiz</title>
      <meta charset="utf-8">
  </head>
  <body>
    <?php include $path.'assets/inc/nav.php'; ?>
    <h1>Quiz: General</h1>
    <form class="quiz-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method='post'>
    <?php
      /*COPY PASTE THIS DO NOT CHANGE IT*/
      $sql = "SELECT * FROM questions WHERE quiz_id = '".$quiz."'";

      $questions = $conn->query($sql);

      if($questions->num_rows > 0){
        $counter = 1;
        while($row = $questions->FETCH_ASSOC()){
          $sql = "SELECT * FROM answers WHERE question = '".$row["question"]."'";
          $allAnswers = $conn->query($sql);
          $questionBlock = '<div class="question"><h3>Question '.$counter.': '.$row['question'].'</h3>';

          if($allAnswers->num_rows > 0){
            while($answer = $allAnswers->FETCH_ASSOC()){
              if($row['multiple-choice'] == 1){
                $questionBlock .= '<span class="answer"><input class="mc" type="radio" name="'.$row['question'].'" value="'.$answer['answer'].'"><label>'.$answer['answer'].'</label></span><br />';
              } else{
                $questionBlock .= '<span class="answer"><input class="long-answer" type="text" name="'.$row['question'].'"></span><br />';
              }
            }
          }else {
            echo 'Something went wrong';
          }

          $questionBlock .= '</div>';
          $counter++;
          echo $questionBlock;
        }
      } else{
        echo 'Something went wrong.';
      }

    ?>
    <input type="submit" value="Submit" name="submit">
  </form>

  <div class="results-container">
    <?php
        /*Now we are handling the results from the quiz
          Present to the user what was right and wrong*/

          //sanitize the data
          function sanitizeToEntities($str, $len=200){
              //$str = strip_tags($str); never use strip_tags!!!!!
              $str = trim($str);
              $str = htmlentities($str, ENT_QUOTES);
              return substr($str, 0, $len);
          }

        //global variables
        $right = 0;
        $counter = 0;
        $resultBlock = "";
        /*
        * Iterate through each key (the quiz questions) in $_POST
        *   and make a call to the db to determine if the value (answers) are correct or not
        *     Once completed, print out to the user
        */
        //if we were sent something
        if(!empty($_POST['submit'])){
          foreach ($_POST as $key => $value) {
            if($key != "submit"){
                $value = strtolower(sanitizeToEntities($value));
				        $key = sanitizeToEntities($key);
                $key = str_replace("_", " ", $key);//$_POST key comes in with spaces as '_', remove them
                /*Get the right answer from the db for the question we are currently on*/
                $sql = "SELECT right_ans FROM questions WHERE question ='".$key."'";
                $result = $conn->query($sql);
                $result = $result->FETCH_ASSOC();
                $ans = strtolower($result['right_ans']);
                /*Now that we have our answer, do stuff with it*/

                  $resultBlock = "<div class='result'><h3>Question: ".$key."</h3>";

                  if($ans == $value){
                    $resultBlock .= "<h4>Your answer was: ".$value."</h4><h5>That is correct!</h5>";
                    $right++;
                  } else{
                    $resultBlock .= "<h4>Your answer was: ".$value."</h4><h5>That is wrong!</h5><h5>The correct answer is: ".$result['right_ans']."</h5>";
                  }

                  $resultBlock .= "</div>";
                  echo $resultBlock;

                  $counter++;
              }
          }


          if($right > 0){
             $percentage = ($right/$counter);
             $percentage = round((float)$percentage * 100 )."%";
             echo "<div class='score'><h6>Your percentage for this quiz is:<span class='percent'>".$percentage."</span></h6></div>";
          } else {
            echo "<div class='score'><h6>Congrats on not trying and getting every question wrong.</h6></div>";
          }
        }
    ?>
  </div><!--End results container-->
  </body>
</html>
