<?php
  $page = 'general';
  $path = '../';
  require $path.'dbConn.php';
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php echo $page; ?> || Reference</title>
  </head>
  <body>
  <?php include $path.'assets/inc/nav.php'; ?>
    <?php
      if($conn){
        $sql = "SELECT content FROM reference WHERE section = '".$page."'";
        $result = $conn->query($sql);
        $result = $result->FETCH_ASSOC();
        $content = $result['content'];
        echo $content;
      } else{
        echo "Oops. Something went wrong.";
      }
     ?>
  </body>
</html>
